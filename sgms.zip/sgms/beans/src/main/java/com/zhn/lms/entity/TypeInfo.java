package com.zhn.lms.entity;

import javax.persistence.*;

@Table(name = "type_info")
public class TypeInfo {
    /**
     * id
     */
    @Id
    private Integer id;

    /**
     * 图书分类名称
     */
    private String name;

    /**
     * 备注
     */
    private String remarks;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取图书分类名称
     *
     * @return name - 图书分类名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置图书分类名称
     *
     * @param name 图书分类名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取备注
     *
     * @return remarks - 备注
     */
    public String getRemarks() {
        return remarks;
    }

    /**
     * 设置备注
     *
     * @param remarks 备注
     */
    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}