package com.zhn.lms.entity;

import java.util.Date;
import javax.persistence.*;

@Table(name = "reader_info")
public class ReaderInfo {
    /**
     * id
     */
    @Id
    private Integer id;

    /**
     * 用户名
     */
    private String username;

    /**
     * 密码
     */
    private String password;

    /**
     * 真实姓名
     */
    @Column(name = "realName")
    private String realname;

    /**
     * 性别
     */
    private String sex;

    /**
     * 出生日期
     */
    private Date birthday;

    /**
     * 籍贯
     */
    private String address;

    /**
     * 电话
     */
    private String tel;

    /**
     * 邮箱
     */
    private String email;

    /**
     * 注册日期
     */
    @Column(name = "registerDate")
    private Date registerdate;

    /**
     * 读者编号
     */
    @Column(name = "readerNumber")
    private String readernumber;

    @Column(name = "readerType")
    private Integer readertype;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取用户名
     *
     * @return username - 用户名
     */
    public String getUsername() {
        return username;
    }

    /**
     * 设置用户名
     *
     * @param username 用户名
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * 获取密码
     *
     * @return password - 密码
     */
    public String getPassword() {
        return password;
    }

    /**
     * 设置密码
     *
     * @param password 密码
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * 获取真实姓名
     *
     * @return realName - 真实姓名
     */
    public String getRealname() {
        return realname;
    }

    /**
     * 设置真实姓名
     *
     * @param realname 真实姓名
     */
    public void setRealname(String realname) {
        this.realname = realname;
    }

    /**
     * 获取性别
     *
     * @return sex - 性别
     */
    public String getSex() {
        return sex;
    }

    /**
     * 设置性别
     *
     * @param sex 性别
     */
    public void setSex(String sex) {
        this.sex = sex;
    }

    /**
     * 获取出生日期
     *
     * @return birthday - 出生日期
     */
    public Date getBirthday() {
        return birthday;
    }

    /**
     * 设置出生日期
     *
     * @param birthday 出生日期
     */
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }

    /**
     * 获取籍贯
     *
     * @return address - 籍贯
     */
    public String getAddress() {
        return address;
    }

    /**
     * 设置籍贯
     *
     * @param address 籍贯
     */
    public void setAddress(String address) {
        this.address = address;
    }

    /**
     * 获取电话
     *
     * @return tel - 电话
     */
    public String getTel() {
        return tel;
    }

    /**
     * 设置电话
     *
     * @param tel 电话
     */
    public void setTel(String tel) {
        this.tel = tel;
    }

    /**
     * 获取邮箱
     *
     * @return email - 邮箱
     */
    public String getEmail() {
        return email;
    }

    /**
     * 设置邮箱
     *
     * @param email 邮箱
     */
    public void setEmail(String email) {
        this.email = email;
    }

    /**
     * 获取注册日期
     *
     * @return registerDate - 注册日期
     */
    public Date getRegisterdate() {
        return registerdate;
    }

    /**
     * 设置注册日期
     *
     * @param registerdate 注册日期
     */
    public void setRegisterdate(Date registerdate) {
        this.registerdate = registerdate;
    }

    /**
     * 获取读者编号
     *
     * @return readerNumber - 读者编号
     */
    public String getReadernumber() {
        return readernumber;
    }

    /**
     * 设置读者编号
     *
     * @param readernumber 读者编号
     */
    public void setReadernumber(String readernumber) {
        this.readernumber = readernumber;
    }

    /**
     * @return readerType
     */
    public Integer getReadertype() {
        return readertype;
    }

    /**
     * @param readertype
     */
    public void setReadertype(Integer readertype) {
        this.readertype = readertype;
    }
}