package com.zhn.lms.entity;

import javax.persistence.*;

@Table(name = "sch_info")
public class SchInfo {
    @Id
    @Column(name = "sch_id")
    private Integer schId;

    @Column(name = "sch_name")
    private String schName;

    /**
     * @return sch_id
     */
    public Integer getSchId() {
        return schId;
    }

    /**
     * @param schId
     */
    public void setSchId(Integer schId) {
        this.schId = schId;
    }

    /**
     * @return sch_name
     */
    public String getSchName() {
        return schName;
    }

    /**
     * @param schName
     */
    public void setSchName(String schName) {
        this.schName = schName;
    }
}