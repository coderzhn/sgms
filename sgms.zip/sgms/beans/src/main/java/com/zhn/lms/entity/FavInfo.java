package com.zhn.lms.entity;

import javax.persistence.*;

@Table(name = "fav_info")
public class FavInfo {
    @Id
    @Column(name = "fav_id")
    private Integer favId;

    @Column(name = "reader_id")
    private Integer readerId;

    @Column(name = "book_id")
    private Integer bookId;

    /**
     * @return fav_id
     */
    public Integer getFavId() {
        return favId;
    }

    /**
     * @param favId
     */
    public void setFavId(Integer favId) {
        this.favId = favId;
    }

    /**
     * @return reader_id
     */
    public Integer getReaderId() {
        return readerId;
    }

    /**
     * @param readerId
     */
    public void setReaderId(Integer readerId) {
        this.readerId = readerId;
    }

    /**
     * @return book_id
     */
    public Integer getBookId() {
        return bookId;
    }

    /**
     * @param bookId
     */
    public void setBookId(Integer bookId) {
        this.bookId = bookId;
    }
}