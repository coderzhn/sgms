package com.zhn.lms.entity;

import java.util.Date;
import javax.persistence.*;

@Table(name = "book_info")
public class BookInfo {
    /**
     * id
     */
    @Id
    private Integer id;

    /**
     * 图书名称
     */
    private String name;

    /**
     * 作者
     */
    private String author;

    /**
     * 出版社
     */
    private String publish;

    /**
     * 书籍编号
     */
    private String isbn;

    /**
     * 简介
     */
    private String introduction;

    /**
     * 语言
     */
    private String language;

    /**
     * 价格
     */
    private Double price;

    /**
     * 出版时间
     */
    @Column(name = "publish_date")
    private Date publishDate;

    /**
     * 书籍类型
     */
    @Column(name = "type_id")
    private Integer typeId;

    /**
     * 状态：0未借出，1已借出
     */
    private Integer status;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取图书名称
     *
     * @return name - 图书名称
     */
    public String getName() {
        return name;
    }

    /**
     * 设置图书名称
     *
     * @param name 图书名称
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * 获取作者
     *
     * @return author - 作者
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置作者
     *
     * @param author 作者
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取出版社
     *
     * @return publish - 出版社
     */
    public String getPublish() {
        return publish;
    }

    /**
     * 设置出版社
     *
     * @param publish 出版社
     */
    public void setPublish(String publish) {
        this.publish = publish;
    }

    /**
     * 获取书籍编号
     *
     * @return isbn - 书籍编号
     */
    public String getIsbn() {
        return isbn;
    }

    /**
     * 设置书籍编号
     *
     * @param isbn 书籍编号
     */
    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    /**
     * 获取简介
     *
     * @return introduction - 简介
     */
    public String getIntroduction() {
        return introduction;
    }

    /**
     * 设置简介
     *
     * @param introduction 简介
     */
    public void setIntroduction(String introduction) {
        this.introduction = introduction;
    }

    /**
     * 获取语言
     *
     * @return language - 语言
     */
    public String getLanguage() {
        return language;
    }

    /**
     * 设置语言
     *
     * @param language 语言
     */
    public void setLanguage(String language) {
        this.language = language;
    }

    /**
     * 获取价格
     *
     * @return price - 价格
     */
    public Double getPrice() {
        return price;
    }

    /**
     * 设置价格
     *
     * @param price 价格
     */
    public void setPrice(Double price) {
        this.price = price;
    }

    /**
     * 获取出版时间
     *
     * @return publish_date - 出版时间
     */
    public Date getPublishDate() {
        return publishDate;
    }

    /**
     * 设置出版时间
     *
     * @param publishDate 出版时间
     */
    public void setPublishDate(Date publishDate) {
        this.publishDate = publishDate;
    }

    /**
     * 获取书籍类型
     *
     * @return type_id - 书籍类型
     */
    public Integer getTypeId() {
        return typeId;
    }

    /**
     * 设置书籍类型
     *
     * @param typeId 书籍类型
     */
    public void setTypeId(Integer typeId) {
        this.typeId = typeId;
    }

    /**
     * 获取状态：0未借出，1已借出
     *
     * @return status - 状态：0未借出，1已借出
     */
    public Integer getStatus() {
        return status;
    }

    /**
     * 设置状态：0未借出，1已借出
     *
     * @param status 状态：0未借出，1已借出
     */
    public void setStatus(Integer status) {
        this.status = status;
    }
}