package com.zhn.lms.entity;

import java.util.Date;
import javax.persistence.*;

public class Comment {
    @Id
    private Integer id;

    private String content;

    @Column(name = "reader_id")
    private Integer readerId;

    private Date date;

    /**
     * @return id
     */
    public Integer getId() {
        return id;
    }

    /**
     * @param id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return content
     */
    public String getContent() {
        return content;
    }

    /**
     * @param content
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * @return reader_id
     */
    public Integer getReaderId() {
        return readerId;
    }

    /**
     * @param readerId
     */
    public void setReaderId(Integer readerId) {
        this.readerId = readerId;
    }

    /**
     * @return date
     */
    public Date getDate() {
        return date;
    }

    /**
     * @param date
     */
    public void setDate(Date date) {
        this.date = date;
    }
}