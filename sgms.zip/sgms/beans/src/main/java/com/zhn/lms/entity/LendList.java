package com.zhn.lms.entity;

import java.util.Date;
import javax.persistence.*;

@Table(name = "lend_list")
public class LendList {
    /**
     * id
     */
    @Id
    private Integer id;

    /**
     * 图书id
     */
    @Column(name = "bookId")
    private Integer bookid;

    /**
     * 读者id
     */
    @Column(name = "readerId")
    private Integer readerid;

    /**
     * 借书时间
     */
    @Column(name = "lendDate")
    private Date lenddate;

    /**
     * 还书时间
     */
    @Column(name = "backDate")
    private Date backdate;

    @Column(name = "backType")
    private Integer backtype;

    /**
     * 备注信息
     */
    @Column(name = "exceptRemarks")
    private String exceptremarks;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * 获取图书id
     *
     * @return bookId - 图书id
     */
    public Integer getBookid() {
        return bookid;
    }

    /**
     * 设置图书id
     *
     * @param bookid 图书id
     */
    public void setBookid(Integer bookid) {
        this.bookid = bookid;
    }

    /**
     * 获取读者id
     *
     * @return readerId - 读者id
     */
    public Integer getReaderid() {
        return readerid;
    }

    /**
     * 设置读者id
     *
     * @param readerid 读者id
     */
    public void setReaderid(Integer readerid) {
        this.readerid = readerid;
    }

    /**
     * 获取借书时间
     *
     * @return lendDate - 借书时间
     */
    public Date getLenddate() {
        return lenddate;
    }

    /**
     * 设置借书时间
     *
     * @param lenddate 借书时间
     */
    public void setLenddate(Date lenddate) {
        this.lenddate = lenddate;
    }

    /**
     * 获取还书时间
     *
     * @return backDate - 还书时间
     */
    public Date getBackdate() {
        return backdate;
    }

    /**
     * 设置还书时间
     *
     * @param backdate 还书时间
     */
    public void setBackdate(Date backdate) {
        this.backdate = backdate;
    }

    /**
     * @return backType
     */
    public Integer getBacktype() {
        return backtype;
    }

    /**
     * @param backtype
     */
    public void setBacktype(Integer backtype) {
        this.backtype = backtype;
    }

    /**
     * 获取备注信息
     *
     * @return exceptRemarks - 备注信息
     */
    public String getExceptremarks() {
        return exceptremarks;
    }

    /**
     * 设置备注信息
     *
     * @param exceptremarks 备注信息
     */
    public void setExceptremarks(String exceptremarks) {
        this.exceptremarks = exceptremarks;
    }
}