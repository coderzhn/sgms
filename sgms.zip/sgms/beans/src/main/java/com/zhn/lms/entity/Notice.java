package com.zhn.lms.entity;

import java.util.Date;
import javax.persistence.*;

public class Notice {
    /**
     * id
     */
    @Id
    private Integer id;

    private String topic;

    /**
     * 公告内容
     */
    private String content;

    /**
     * 发布人
     */
    private String author;

    /**
     * 公告发布时间
     */
    @Column(name = "createDate")
    private Date createdate;

    /**
     * 获取id
     *
     * @return id - id
     */
    public Integer getId() {
        return id;
    }

    /**
     * 设置id
     *
     * @param id id
     */
    public void setId(Integer id) {
        this.id = id;
    }

    /**
     * @return topic
     */
    public String getTopic() {
        return topic;
    }

    /**
     * @param topic
     */
    public void setTopic(String topic) {
        this.topic = topic;
    }

    /**
     * 获取公告内容
     *
     * @return content - 公告内容
     */
    public String getContent() {
        return content;
    }

    /**
     * 设置公告内容
     *
     * @param content 公告内容
     */
    public void setContent(String content) {
        this.content = content;
    }

    /**
     * 获取发布人
     *
     * @return author - 发布人
     */
    public String getAuthor() {
        return author;
    }

    /**
     * 设置发布人
     *
     * @param author 发布人
     */
    public void setAuthor(String author) {
        this.author = author;
    }

    /**
     * 获取公告发布时间
     *
     * @return createDate - 公告发布时间
     */
    public Date getCreatedate() {
        return createdate;
    }

    /**
     * 设置公告发布时间
     *
     * @param createdate 公告发布时间
     */
    public void setCreatedate(Date createdate) {
        this.createdate = createdate;
    }
}