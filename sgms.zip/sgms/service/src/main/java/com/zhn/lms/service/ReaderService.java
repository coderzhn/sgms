package com.zhn.lms.service;


import com.zhn.lms.entity.BookInfo;
import com.zhn.lms.entity.Comment;
import com.zhn.lms.entity.FavInfo;
import com.zhn.lms.entity.LendList;

import java.util.List;

public interface ReaderService
{
    List<BookInfo> bookSearch();
    //收藏管理接口
    int insertFav(FavInfo favInfo);
    int deleteFav(int id);
    //评价管理接口
    List<Comment> commentSearch();
    int insertCom(Comment comment);
    int deleteCom(int id);
    //更改借阅状态
    int updateLendlist(LendList lendList);

}
