package com.zhn.lms.service.impl;

import com.zhn.lms.dao.AdminMapper;
import com.zhn.lms.dao.ReaderInfoMapper;
import com.zhn.lms.entity.Admin;
import com.zhn.lms.entity.ReaderInfo;
import com.zhn.lms.service.LoginService;
import com.zhn.lms.vo.ResStatus;
import com.zhn.lms.vo.ResultVO;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.List;

@Scope("singleton")
@Service
public class LoginServiceImpl implements LoginService
{
    @Resource
    ReaderInfoMapper readerInfoMapper;
    @Resource
    AdminMapper adminMapper;
    @Override
    public ResultVO login(String username, String password)
    {
        Example example = new Example(Admin.class);
        example.createCriteria()
                .andEqualTo("username",username);
        List<Admin> admins = adminMapper.selectByExample(example);

        Example example2 = new Example(ReaderInfo.class);
        example2.createCriteria()
                .andEqualTo("username",username);
        List<ReaderInfo> readerInfos = readerInfoMapper.selectByExample(example2);

        if (admins.size()==0 && readerInfos.size()==0)
        {
            return new ResultVO(ResStatus.NO,"NO such account!",null);
        }else if (admins.size()!=0 && readerInfos.size()==0){
            String password1 = admins.get(0).getPassword();
            if (password1.equals(password)){
                return new ResultVO(ResStatus.OK,"success",admins.get(0));
            }else {
                return new ResultVO(ResStatus.NO,"password error",null);
            }
        }else if(admins.size()==0 && readerInfos.size()!=0){
            String password1 = readerInfos.get(0).getPassword();
            if (password1.equals(password)){
                return new ResultVO(ResStatus.OK,"success",readerInfos.get(0));
            }else {
                return new ResultVO(ResStatus.NO,"password error",null);
            }
        }
        return new ResultVO(ResStatus.NO,"error",null);
    }
}
