package com.zhn.lms.service.impl;

import com.zhn.lms.dao.*;
import com.zhn.lms.entity.*;
import com.zhn.lms.service.AdminService;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;
import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@Service
@Scope("singleton")
public class AdminServiceImpl implements AdminService {
    @Resource
    private NoticeMapper noticeMapper;
    @Resource
    private BookInfoMapper bookInfoMapper;
    @Resource
    private TypeInfoMapper typeInfoMapper;
    @Resource
    private SchInfoMapper schInfoMapper;
    @Resource
    private ReaderInfoMapper readerInfoMapper;
    @Resource
    private LendListMapper lendListMapper;
    @Override
    public List<Notice> noticeSearch() {
        List<Notice> notices = noticeMapper.selectAll();
        return notices;
    }

    @Override
    public int deleteNotice(int id)
    {
        Example example = new Example(Notice.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("id",id);
        int i = noticeMapper.deleteByExample(example); //
        return i;
    }

    @Override
    public int insertNotice(Notice notice)
    {
        int insert = noticeMapper.insert(notice);
        return insert;
    }

    @Override
    public int updateNotice(Notice notice)
    {
        int i = noticeMapper.updateByPrimaryKeySelective(notice);
        if(i!=0)
            return i;
        return 0;
    }

    @Override
    public  List<BookInfo> bookSearch() {
        List<BookInfo> bookInfos = bookInfoMapper.selectAll();
        return bookInfos;
    }

    @Override
    public int deleteBook(String name) {
        Example example = new Example(BookInfo.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("name",name);
        int i = bookInfoMapper.deleteByExample(example); //
        return i;
    }

    @Override
    public int insertBook(BookInfo bookInfo) {
        int insert = bookInfoMapper.insert(bookInfo);
        return insert;
    }

    @Override
    public int updateBacktype(int id,int backtype) {
        LendList lendList = new LendList();
        lendList.setId(id);
        lendList.setBacktype(backtype);
        int i = lendListMapper.updateByPrimaryKeySelective(lendList);
       if(i!=0)
           return i;
       return 0;
    }

    @Override
    public int updateDate(int id,Date date) {
        LendList lendList = new LendList();
        lendList.setId(id);
        lendList.setBackdate(date);
        int i = lendListMapper.updateByPrimaryKeySelective(lendList);
        return i;
    }

    @Override
    public List<TypeInfo> typeSearch() {
        List<TypeInfo> typeInfos = typeInfoMapper.selectAll();
        return typeInfos;
    }

    @Override
    public int deleteType(String typeName) {
        Example example = new Example(TypeInfo.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("name",typeName);
        int i = typeInfoMapper.deleteByExample(example);
        return i;
    }

    @Override
    public int insertType(TypeInfo typeInfo) {
        int insert = typeInfoMapper.insert(typeInfo);
        return insert;
    }

    @Override
    public int updateType(TypeInfo typeInfo) {
        int i = typeInfoMapper.updateByPrimaryKeySelective(typeInfo);
        if(i!=0)
            return i;
        return 0;
    }

    @Override
    public List<SchInfo> schoolSearch() {
        return schInfoMapper.selectAll();
    }

    @Override
    public int deleteSch(String name) {
        Example example = new Example(SchInfo.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("schName",name);
        return schInfoMapper.deleteByExample(example);

    }

    @Override
    public int insertSch(SchInfo schInfo) {
        return schInfoMapper.insert(schInfo);
    }

    @Override
    public int updateSch(SchInfo schInfo) {
        int i = schInfoMapper.updateByPrimaryKeySelective(schInfo);
        if(i!=0)
            return i;
        return 0;
    }

    @Override
    public List<ReaderInfo> readerSearch() {
        List<ReaderInfo> readerInfos = readerInfoMapper.selectAll();
        return readerInfos;
    }

    @Override
    public int deleteReader(String name) {
        Example example = new Example(ReaderInfo.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("username",name);
        int i = readerInfoMapper.deleteByExample(example);
        return i;
    }

    @Override
    public int insertReader(ReaderInfo readerInfo) {
        return readerInfoMapper.insert(readerInfo);
    }

    @Override
    public int updateReader(ReaderInfo readerInfo) {
        int i = readerInfoMapper.updateByPrimaryKeySelective(readerInfo);
        if(i!=0)
            return i;
        return 0;
    }

    @Override
    public List<LendList> leadListSearch() {
        List<LendList> lendLists = lendListMapper.selectAll();
        return lendLists;
    }

    @Override
    public int insertLendList(LendList lendList) {
        int insert = lendListMapper.insert(lendList);
        return insert;
    }

    @Override
    public int updateLendList(LendList lendList) {
        int i = lendListMapper.updateByPrimaryKeySelective(lendList);
        if(i!=0)
            return 1;
        return 0;
    }

}
