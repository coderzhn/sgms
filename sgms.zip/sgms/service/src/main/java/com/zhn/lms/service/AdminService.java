package com.zhn.lms.service;

import com.zhn.lms.entity.*;

import java.util.Date;
import java.util.List;

public interface AdminService
{
    //公告管理
    List<Notice> noticeSearch();
    int deleteNotice(int id);
    int insertNotice(Notice notice);
    int updateNotice(Notice notice);
    //图书管理
    List<BookInfo> bookSearch();
    int deleteBook(String bookName);
    int insertBook(BookInfo bookInfo);
    int updateBacktype(int id,int backtype);
    int updateDate(int id,Date date);
    //分类管理
    List<TypeInfo> typeSearch();
    int deleteType(String typeName);
    int insertType(TypeInfo typeInfo);
    int updateType(TypeInfo typeInfo);
    //学校管理
    List<SchInfo> schoolSearch();
    int deleteSch(String name);
    int insertSch(SchInfo schInfo);
    int updateSch(SchInfo schInfo);
    //读者管理
    List<ReaderInfo> readerSearch();
    int deleteReader(String name);
    int insertReader(ReaderInfo readerInfo);
    int updateReader(ReaderInfo readerInfo);
    //借阅记录管理
    List<LendList> leadListSearch();
    int insertLendList(LendList lendList);
    int updateLendList(LendList lendList);

}
