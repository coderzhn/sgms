package com.zhn.lms.service;

import com.zhn.lms.vo.ResultVO;

public interface LoginService
{
    ResultVO login(String username,String password);
}
