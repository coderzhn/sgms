package com.zhn.lms.service.impl;

import com.zhn.lms.dao.BookInfoMapper;
import com.zhn.lms.dao.CommentMapper;
import com.zhn.lms.dao.FavInfoMapper;
import com.zhn.lms.dao.LendListMapper;
import com.zhn.lms.entity.BookInfo;
import com.zhn.lms.entity.Comment;
import com.zhn.lms.entity.FavInfo;
import com.zhn.lms.entity.LendList;
import com.zhn.lms.service.ReaderService;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;
import tk.mybatis.mapper.entity.Example;

import javax.annotation.Resource;
import java.util.List;

@Scope("singleton")
@Service
public class ReaderServiceImpl implements ReaderService
{
    @Resource
    private BookInfoMapper bookInfoMapper; //注入mapper
    @Resource
    private FavInfoMapper favInfoMapper;
    @Resource
    private CommentMapper commentMapper;
    @Resource
    private LendListMapper lendListMapper;
    @Override
    public List<BookInfo> bookSearch() {
        List<BookInfo> bookInfos = bookInfoMapper.selectAll();
        return bookInfos;
    }

    @Override
    public int insertFav(FavInfo favInfo) {
        return favInfoMapper.insert(favInfo);
    }

    @Override
    public int deleteFav(int id) {
        Example example = new Example(FavInfo.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("bookId",id);
        int i = favInfoMapper.deleteByExample(example);
        return i;
    }

    @Override
    public List<Comment> commentSearch() {
        return commentMapper.selectAll();
    }

    @Override
    public int insertCom(Comment comment) {
        return commentMapper.insert(comment);
    }

    @Override
    public int deleteCom(int id) {
        Example example = new Example(Comment.class);
        Example.Criteria criteria = example.createCriteria();
        criteria.andEqualTo("id",id);
        return commentMapper.deleteByExample(example);
    }

    @Override
    public int updateLendlist(LendList lendList) {
        int i = lendListMapper.updateByPrimaryKeySelective(lendList);
        if(i!=0)
            return 1;
        return 0;
    }

}
