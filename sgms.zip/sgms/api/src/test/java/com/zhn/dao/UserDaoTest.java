package com.zhn.dao;

import com.zhn.lms.ApiApplication;
import org.junit.runner.RunWith;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = ApiApplication.class)
public class UserDaoTest {

//    @Resource
//    private UserDao userDao;
//
//    @Test
//    public void queryTest(){
//        User user = userDao.queryUserByName("hewei");
//        System.out.println(user);
//    }
}
