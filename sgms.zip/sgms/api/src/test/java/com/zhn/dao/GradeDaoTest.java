package com.zhn.dao;


    import com.zhn.lms.ApiApplication;
    import org.junit.runner.RunWith;
    import org.springframework.boot.test.context.SpringBootTest;
    import org.springframework.test.context.junit4.SpringRunner;

    @RunWith(SpringRunner.class)
    @SpringBootTest(classes = ApiApplication.class)
    public class GradeDaoTest {

    //    @Autowired
    //    GradeMapper gradeMapper;
    //
    //    @Test
    //    public void  testFind(){
    //        Grade result = gradeMapper.findByStuId(2019905349);
    //
    //        System.out.println(result);
    //    }


    }
