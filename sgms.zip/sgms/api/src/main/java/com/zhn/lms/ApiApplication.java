package com.zhn.lms;


import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import tk.mybatis.spring.annotation.MapperScan;

@SpringBootApplication//让当前类作为一个配置类交由 Spring 的 IOC 容器进行管理
@MapperScan("com.zhn.lms.dao")//编译之后会生成相应的接口实现类
public class ApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(ApiApplication.class, args);
        /*
        为应用创建一个合适的ApplicationContext
        注册一个CommandLinePropertySource，通过CommandLinePropertySource可以对外暴露命令行参数，并将命令行参数与spring应用中用到的properties关联起来
        启动ApplicationContext
        执行所有的CommandLineRunner类型bean
         */
    }

}
