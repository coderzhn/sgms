package com.zhn.lms.controller;

import com.zhn.lms.service.LoginService;
import com.zhn.lms.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;

@RestController
@RequestMapping("/login")
@Api(value = "login接口",tags = "登录管理")
@CrossOrigin
public class LoginController{
    @Resource
    private LoginService loginService;

    @ApiOperation("登录校验接口")
    @ApiImplicitParams({        // 文档中的参数说明
            @ApiImplicitParam(dataType = "string", name = "username",value = "用户注册账号",required = true),
            @ApiImplicitParam(dataType = "string", name = "password",value = "用户注册密码",required = true)
    })
    @GetMapping("/lg")
    public ResultVO login(@RequestParam("username") String username,
                          @RequestParam("password") String password){
        return loginService.login(username,password);
    }
}
