package com.zhn.lms.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.builders.PathSelectors;
import springfox.documentation.builders.RequestHandlerSelectors;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.service.Contact;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;

//接口自动生成器swagger调用

@Configuration
@EnableSwagger2
public class SwaggerConfig {

    //Docket :把操作系统,jdk,tomcat,代码,配置全部放到集装箱里.再打包放到鲸鱼上
    // ,由鲸鱼给我们送到服务器上,在我的机器上怎么运行,在别的机器上也怎么运行.不会有任何的问题.一句话就是docker解决了运行环境不一致所带来的问题.
    @Bean //产生一个Bean对象，然后这个Bean对象交给Spring管理。产生这个Bean对象的方法Spring只会调用一次
            // ，随后这个Spring将会将这个Bean对象放在自己的IOC容器中；把已经在xml文件中配置好的Bean拿来用
    public Docket getDocket(){

        ApiInfoBuilder apiInfoBuilder = new ApiInfoBuilder();
        //项目及其作者相关信息
        apiInfoBuilder.title("《图书信息管理系统》后端接口说明")
                .description("此文档详细说明了项目后端的接口规范")
                .version("2.0.1")
                .contact(new Contact("Zhanghaonan","www.baidu.com","1481929167@qq.com"));
        ApiInfo apiInfo = apiInfoBuilder.build(); //配置api的基本信息


        Docket docket = new Docket(DocumentationType.SWAGGER_2)
                .apiInfo(apiInfo)
                .select()
                .apis(RequestHandlerSelectors.basePackage("com.zhn.lms.controller"))
                .paths(PathSelectors.any())
                .build();

        return docket;
    }
}
