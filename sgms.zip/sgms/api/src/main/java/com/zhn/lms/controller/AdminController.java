package com.zhn.lms.controller;


import com.zhn.lms.entity.*;
import com.zhn.lms.service.AdminService;
import com.zhn.lms.vo.ResStatus;
import com.zhn.lms.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;
import javax.annotation.Resource;
import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/admin")
@Api(value = "管理员接口",tags = "管理")
@CrossOrigin
public class AdminController
{

    @Resource
    private AdminService adminService;

    @ApiOperation("查找公告接口")
    @GetMapping("/fnotice")
    public ResultVO findNoticeById()
    {
        List<Notice> notices = adminService.noticeSearch();
        return new ResultVO(ResStatus.OK,"查询成功",notices);
    }
    @ApiOperation("删除公告接口")
    @ApiImplicitParam(dataType = "int", name = "id",value = "公告id",required = true)
    @DeleteMapping("/dnotice")
    public ResultVO deleteNoticeById(int id)
    {
        int flag = adminService.deleteNotice(id);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("插入公告接口")
    @ApiImplicitParam(dataType = "Notice", name = "notice",value = "公告id",required = true)
    @PostMapping("/inotice")
    public ResultVO insertNotice(@RequestBody Notice notice)
    {
        int flag = adminService.insertNotice(notice);
        return new ResultVO(ResStatus.OK,"插入成功",flag);
    }
    @ApiOperation("修改公告接口")
    @PutMapping("/unotice")
    public ResultVO updateNotice(@RequestBody Notice notice)
    {
        int flag = adminService.updateNotice(notice);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }

    @ApiOperation("查找图书信息接口")
    @GetMapping("/fbookinfo")
    public ResultVO findBookinfoById()
    {
        List<BookInfo> bookInfo = adminService.bookSearch();
        return new ResultVO(ResStatus.OK,"查询成功",bookInfo);
    }
    @ApiOperation("删除图书信息接口")
    @ApiImplicitParam(dataType = "String", name = "name",value = "图书名称",required = true)
    @DeleteMapping("/dbookinfo")
    public ResultVO deleteBookinfoById(String name)
    {
        int flag = adminService.deleteBook(name);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("插入图书信息接口")
    @ApiImplicitParam(dataType = "BookInfo", name = "bookinfo",value = "图书信息",required = true)
    @PostMapping("/ibookinfo")
    public ResultVO insertNotice(@RequestBody BookInfo bookInfo)
    {
        int flag = adminService.insertBook(bookInfo);
        return new ResultVO(ResStatus.OK,"插入成功",flag);
    }
    @ApiOperation("修改借阅状态接口")
    @PutMapping("/ubacktype")
    public ResultVO updateBacktype(@RequestParam("id")Integer id,@RequestParam("backtype")Integer backtype)
    {
        int flag = adminService.updateBacktype(id,backtype);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }

    @ApiOperation("查找分类信息接口")
    @GetMapping("/ftypeinfo")
    public ResultVO findTypeinfoById()
    {
        List<TypeInfo> typeInfos = adminService.typeSearch();
        return new ResultVO(ResStatus.OK,"查询成功",typeInfos);
    }
    @ApiOperation("删除分类信息接口")
    @ApiImplicitParam(dataType = "String", name = "name",value = "分类名",required = true)
    @DeleteMapping("/dtypeinfo")
    public ResultVO deleteTypeinfoById(@RequestParam("name") String name)
    {
        int flag = adminService.deleteType(name);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("插入分类信息接口")
    @ApiImplicitParam(dataType = "TypeInfo", name = "typeinfo",value = "分类信息",required = true)
    @PostMapping("/itypeinfo")
    public ResultVO insertNotice(@RequestBody TypeInfo typeInfo)
    {
        int flag = adminService.insertType(typeInfo);
        return new ResultVO(ResStatus.OK,"插入成功",flag);
    }
    @ApiOperation("修改分类信息接口")
    @PutMapping("/utypeinfo")
    public ResultVO updateTypeinfo(@RequestBody TypeInfo typeInfo)
    {
        int flag = adminService.updateType(typeInfo);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }
    @ApiOperation("查找学校信息接口")
    @GetMapping("/fschinfo")
    public ResultVO findSchinfoById()
    {
        List<SchInfo> schInfos = adminService.schoolSearch();
        return new ResultVO(ResStatus.OK,"查询成功",schInfos);
    }
    @ApiOperation("删除学校信息接口")
    @ApiImplicitParam(dataType = "String", name = "name",value = "学校姓名",required = true)
    @DeleteMapping("/dschinfo")
    public ResultVO deleteSchinfoById(String name)
    {
        int flag = adminService.deleteSch(name);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("插入学校信息接口")
    @ApiImplicitParam(dataType = "SchInfo", name = "schinfo",value = "学校信息",required = true)
    @PostMapping("/ischinfo")
    public ResultVO insertSchool(@RequestBody SchInfo schInfo)
    {
        int flag = adminService.insertSch(schInfo);
        return new ResultVO(ResStatus.OK,"插入成功",flag);
    }
    @ApiOperation("修改学校信息接口")
    @PutMapping("/uschinfo")
    public ResultVO updateSchinfo(@RequestBody SchInfo schInfo)
    {
        int flag = adminService.updateSch(schInfo);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }

    @ApiOperation("查找读者信息接口")
    @GetMapping("/freaderinfo")
    public ResultVO findReaderinfo()
    {
        List<ReaderInfo> readerInfo = adminService.readerSearch();
        return new ResultVO(ResStatus.OK,"查询成功",readerInfo);
    }
    @ApiOperation("删除读者信息接口")
    @ApiImplicitParam(dataType = "String", name = "name",value = "读者姓名",required = true)
    @DeleteMapping("/dreaderinfo")
    public ResultVO deleteReaderinfoByName(String name)
    {
        int flag = adminService.deleteReader(name);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("插入读者信息接口")
    @PostMapping("/ireaderinfo")
    public ResultVO insertReader(@RequestBody ReaderInfo readerInfo)
    {
        int flag = adminService.insertReader(readerInfo);
        return new ResultVO(ResStatus.OK,"插入成功",flag);
    }
    @ApiOperation("修改读者信息接口")
    @PutMapping("/ureaderinfo")
    public ResultVO updateSchinfo(@RequestBody ReaderInfo readerInfo)
    {
        int flag = adminService.updateReader(readerInfo);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }

    @ApiOperation("查找借阅信息接口")
    @GetMapping("/flendlist")
    public ResultVO findLendlist()
    {
        List<LendList> lendLists = adminService.leadListSearch();
        return new ResultVO(ResStatus.OK,"查询成功",lendLists);
    }
    @ApiOperation("添加借阅信息接口")
    @ApiImplicitParam(dataType = "LeadList", name = "leadList",value = "借阅信息",required = true)
    @PostMapping("/ilendlist")
    public ResultVO insertLendlistr(@RequestBody LendList lendList)
    {
        int i = adminService.insertLendList(lendList);
        return new ResultVO(ResStatus.OK,"插入成功",i);
    }
    @ApiOperation("修改借阅信息接口")
    @PutMapping("/ulendlist")
    public ResultVO updateLendlist(@RequestBody LendList lendList)
    {
        int flag = adminService.updateLendList(lendList);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }
    @ApiOperation("更改借阅时长接口")
    @PutMapping("/udlendlist")
    public ResultVO updateDate(@RequestParam("id")int id, @RequestParam("backDate")@DateTimeFormat(pattern="yyyy-MM-dd HH:mm:ss") Date date)
    {
        int flag = adminService.updateDate(id,date);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }
}
