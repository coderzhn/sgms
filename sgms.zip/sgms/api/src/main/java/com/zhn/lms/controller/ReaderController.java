package com.zhn.lms.controller;

import com.zhn.lms.entity.*;
import com.zhn.lms.service.ReaderService;
import com.zhn.lms.vo.ResStatus;
import com.zhn.lms.vo.ResultVO;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import java.util.List;

@RestController
@RequestMapping("/reader")
@Api(value = "读者接口",tags = "读者功能")
@CrossOrigin
public class ReaderController
{
    @Resource
    ReaderService readerService;
    @ApiOperation("查找图书信息接口")
    @GetMapping("/fbookinfo")
    public ResultVO findBookinfoById()
    {
        List<BookInfo> bookInfo = readerService.bookSearch();
        return new ResultVO(ResStatus.OK,"查询成功",bookInfo);
    }

    @ApiOperation("插入收藏信息接口")
    @ApiImplicitParam(dataType = "Favinfo", name = "favinfo",value = "收藏信息信息",required = true)
    @PostMapping("/ifavinfo")
    public ResultVO insertSchool(@RequestBody FavInfo favInfo)
    {
        int i = readerService.insertFav(favInfo);
        return new ResultVO(ResStatus.OK,"插入成功",i);
    }

    @ApiOperation("删除学校信息接口")
    @ApiImplicitParam(dataType = "String", name = "name",value = "学校姓名",required = true)
    @DeleteMapping("/dschinfo")
    public ResultVO deleteFavinfoById(int id)
    {
        int flag = readerService.deleteFav(id);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("查找评论信息接口")
    @GetMapping("/fcominfo")
    public ResultVO findComment()
    {
        List<Comment> comments = readerService.commentSearch();
        return new ResultVO(ResStatus.OK,"查询成功",comments);
    }
    @ApiOperation("插入评论信息接口")
    @ApiImplicitParam(dataType = "Comment", name = "comment",value = "评论信息",required = true)
    @PostMapping("/icomment")
    public ResultVO insertSchool(@RequestBody Comment comment)
    {
        int i = readerService.insertCom(comment);
        return new ResultVO(ResStatus.OK,"插入成功",i);
    }

    @ApiOperation("删除评论信息接口")
    @ApiImplicitParam(dataType = "int", name = "id",value = "评论id",required = true)
    @DeleteMapping("/dcomment")
    public ResultVO deleteCommentById(int id)
    {
        int flag = readerService.deleteCom(id);
        return new ResultVO(ResStatus.OK,"删除成功",flag);
    }
    @ApiOperation("修改状态信息接口")
    @PutMapping("/ulendlist")
    public ResultVO updatelendlist(@RequestBody LendList lendList)
    {
        int flag = readerService.updateLendlist(lendList);
        return new ResultVO(ResStatus.OK,"修改成功",flag);
    }
}
