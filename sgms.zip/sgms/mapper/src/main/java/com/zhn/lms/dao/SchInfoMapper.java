package com.zhn.lms.dao;

import com.zhn.lms.entity.SchInfo;
import com.zhn.lms.general.GeneralDAO;

public interface SchInfoMapper extends GeneralDAO<SchInfo> {
}