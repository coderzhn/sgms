package com.zhn.lms.dao;

import com.zhn.lms.entity.LendList;
import com.zhn.lms.general.GeneralDAO;

public interface LendListMapper extends GeneralDAO<LendList> {
}