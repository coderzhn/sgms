package com.zhn.lms.dao;

import com.zhn.lms.entity.TypeInfo;
import com.zhn.lms.general.GeneralDAO;

public interface TypeInfoMapper extends GeneralDAO<TypeInfo> {
}