package com.zhn.lms.dao;

import com.zhn.lms.entity.ReaderInfo;
import com.zhn.lms.general.GeneralDAO;

public interface ReaderInfoMapper extends GeneralDAO<ReaderInfo> {
}