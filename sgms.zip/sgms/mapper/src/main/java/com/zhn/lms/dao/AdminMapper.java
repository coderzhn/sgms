package com.zhn.lms.dao;

import com.zhn.lms.entity.Admin;
import com.zhn.lms.general.GeneralDAO;

public interface AdminMapper extends GeneralDAO<Admin> {
}