package com.zhn.lms.dao;

import com.zhn.lms.entity.Comment;
import com.zhn.lms.general.GeneralDAO;

public interface CommentMapper extends GeneralDAO<Comment> {
}