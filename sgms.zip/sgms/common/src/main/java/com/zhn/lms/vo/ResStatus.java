package com.zhn.lms.vo;

/**
 * @Author: 张浩楠
 * @Description: 返回值Code的枚举类
 */

public class ResStatus {
    public static final int OK=10000;
    public static final int NO=10001;
    public static final int LOGIN_SUCCESS = 20000;     // 登录认证成功
    public static final int LOGIN_FAIL_NOT = 20001;    // 用户未登录
    public static final int LOGIN_FAIL_OVERDUE = 20002;// 登录过期
}